from setuptools import setup, find_packages

setup(
    name='sql_task',
    version='0.1',
    description='Cherre programming exercise',
    author='Andrew Lange',
    classifiers=['License :: OSI Approved :: MIT License',
                 'Programming Language :: Python :: 3.6'
    ]
)