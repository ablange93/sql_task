# sql_task
Python application for querying a SQLite3 database.
